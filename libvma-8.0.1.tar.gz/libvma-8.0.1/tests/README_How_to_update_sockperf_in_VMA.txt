As of Oct 2015, sockperf was entirely splitted out of VMA.
sockperf is anyhow a standalone project in github (and previously in googlecode).
Recently sockperf started to have an *.rpm and *.deb for itself.
Resources:
	https://github.com/Mellanox/sockperf
	http://rpmfind.net/linux/rpm2html/search.php?query=sockperf
